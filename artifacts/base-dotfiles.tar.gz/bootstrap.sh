#!/usr/bin/env bash

set -eo pipefail

WSL_CONF='
[automount]
enabled = true
options = "metadata,umask=22,fmask=11"
mountFsTab = false

[network]
generateResolvConf = false

[boot]
systemd=true
'

JOB_SUMMARY=""
# https://superuser.com/a/1767649
WSL_DISTRO_SAFE_NAME=$(echo "$WSL_DISTRO_NAME" | tr -d '-' | tr -d '.')
WSL2_SYSTEMD_MOUNT="/etc/systemd/system/mnt-wsl-instances-${WSL_DISTRO_SAFE_NAME}.mount"
WSL2_SYSTEMD_MOUNT_CONTENTS="
[Unit]
Description=WSL Instances

[Mount]
What=/
Where=/mnt/wsl/instances/${WSL_DISTRO_SAFE_NAME}
Type=none
Options=defaults,bind,X-mount.mkdir

[Install]
WantedBy=multi-user.target
"

APT_PREFER_MOZILLA='
Package: *
Pin: origin packages.mozilla.org
Pin-Priority: 1000

Package: firefox*
Pin: release o=Ubuntu
Pin-Priority: -1'

generate_resolv_conf() {
  powershell.exe -Command "Get-DnsClientServerAddress -AddressFamily ipv4 | Select-Object -ExpandProperty ServerAddresses" | sed 's/\r//g' | sort -u | xargs -n 1 echo nameserver
}

action_help() {
  cat << EOF

New Machine bootstrap; some attention required

Usage: $(basename "$0") [bootstrap | userspace | apps | all | help]
  all        : All the tasks
  bootstrap  : First things first
  apps       : tailscale + firefox
  userspace  : ubuntu-dpm etc
  # After this there's ubuntu-dpm
  help       : Show this help

env-var control
  WSL_DISTRO_NAME     : [$WSL_DISTRO_NAME]
  XDG_CURRENT_DESKTOP : [$XDG_CURRENT_DESKTOP]
  SKIP_KEYGEN         : [$SKIP_KEYGEN]
  TAILSCALE_DISABLE   : [$TAILSCALE_DISABLE]
  SKIP_DOCKER         : [$SKIP_DOCKER]

EOF
 exit 1
}

action_bootstrap() {
  echo "$USER ALL=(ALL:ALL) NOPASSWD:ALL" | sudo tee -a /etc/sudoers.d/lenient
  sudo apt update && sudo apt -y install vim nfs-common unison jq direnv zip unzip net-tools git rcm bash-completion curl xxd
  if [[ -z "$WSL_DISTRO_NAME" ]]; then
    sudo apt-get -y install openssh-server
  fi
  if [[ -z "$WSL_DISTRO_NAME" && -n "${XDG_CURRENT_DESKTOP}" ]]; then
    sudo apt-get -y install fonts-firacode
  fi
  sudo update-alternatives --set editor /usr/bin/vim.basic
  sudo apt -y autoremove
  if [[ -z "$SKIP_KEYGEN" ]]; then
    if [[ ! -f ~/.ssh/id_ed25519 && ! -f ~/.ssh/id_rsa ]]; then
      ssh-keygen -t ed25519 -a 96
    fi
  fi
  if [[ -n "$WSL_DISTRO_NAME" ]]; then
    if [[ ! -f /etc/wsl.conf || -n "$OVERRIDE_DNS" ]]; then
      echo "$WSL_CONF" | sudo tee /etc/wsl.conf
      sudo rm -f /etc/resolv.conf
      generate_resolv_conf | sudo tee /etc/resolv.conf
      JOB_SUMMARY+="\n>>> /etc/wsl.conf modified, you need to restart WSL"
    fi
    echo "$WSL2_SYSTEMD_MOUNT_CONTENTS" | sudo tee "$WSL2_SYSTEMD_MOUNT"
    sudo systemctl daemon-reload || true
    sudo systemctl enable mnt-wsl-instances-"${WSL_DISTRO_SAFE_NAME%-*}".mount --now || true
  fi
}

action_userspace() {
  if [[ ! -f "$HOME/.rcrc" ]]; then
    cp rcrc $HOME/.rcrc
  fi
  if builtin type -p rcup; then
    rcup
  fi
  if [[ -d "$HOME/ubuntu-dpm" ]]; then
    pushd $HOME/ubuntu-dpm
    git pull --rebase
    popd >/dev/null
  else
    pushd $HOME >/dev/null
    git clone http://github.com/quotidian-ennui/ubuntu-dpm
    popd >/dev/null
  fi
  pushd "$HOME/ubuntu-dpm" >/dev/null
  ./bootstrap.sh repos
  ./bootstrap.sh baseline
  $HOME/.local/bin/just tools
  popd >/dev/null
}

action_apps() {
  local mozilla_key="/usr/share/keyrings/mozilla-packages.gpg"
  local tailscale_key="/usr/share/keyrings/tailscale-archive-keyring.gpg"

  if [[ -z "$WSL_DISTRO_NAME" && -n "${XDG_CURRENT_DESKTOP}" ]]; then
    curl -fsSL "https://packages.mozilla.org/apt/repo-signing-key.gpg" | gpg --no-tty --batch --dearmor | sudo tee "$mozilla_key" >/dev/null
    echo "deb [arch=$(dpkg --print-architecture) signed-by=$mozilla_key] https://packages.mozilla.org/apt mozilla main" | sudo tee /etc/apt/sources.list.d/mozilla.list >/dev/null
    echo "$APT_PREFER_MOZILLA" | sudo tee /etc/apt/preferences.d/mozilla >/dev/null

    sudo apt -y update
    sudo snap remove firefox || true
    sudo apt -y install --allow-downgrades firefox 
    if [[ -z "$TAILSCALE_DISABLE" ]]; then
      curl -fsSL https://pkgs.tailscale.com/stable/ubuntu/noble.noarmor.gpg | sudo tee "$tailscale_key" >/dev/null
      curl -fsSL https://pkgs.tailscale.com/stable/ubuntu/noble.tailscale-keyring.list | sudo tee /etc/apt/sources.list.d/tailscale.list >/dev/null
      sudo apt -y install tailscale
    fi
  fi
}

action_all() {
  action_bootstrap
  action_apps
  action_userspace
}

mkdir -p ~/.local/bin

ACTION=$1 || true
ACTION=${ACTION:-"help"}
case $ACTION in
  bootstrap|help|userspace|apps|all)
    ;;
  *)
    ACTION="help"
    ;;
esac

action_"$ACTION"

echo -e "$JOB_SUMMARY"
