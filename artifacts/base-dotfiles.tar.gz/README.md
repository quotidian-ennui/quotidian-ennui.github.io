# Base Minimum user-env

Dotfiles and things managed via rcm

Everything depends on your .rcrc file

- narrow to wide in tagging
- override HOSTNAME for wsl2 instances
