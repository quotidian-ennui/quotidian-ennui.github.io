Task:

Write an ant task that can delete all the records from each table in a given database.

Notes:
* Check build.xml for the parameters that are used to invoke the task
* build.xml also includes the taskdef, you may wish to change it.


