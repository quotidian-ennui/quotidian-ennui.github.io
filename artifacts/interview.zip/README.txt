On the CD is everything you should need to get going on answering the interview questions.
I have included a Java install and apache-ant in case you do not already have it

Extract interview.zip and follow the instructions contained in each directory.

This is an open-book set of questions, there are no right or wrong answers.
This is purely to get a feel for how you approach problems and what

Spend as long or as short as you like on it, and send me the completed src files to
lewin.chan@adaptris.com
