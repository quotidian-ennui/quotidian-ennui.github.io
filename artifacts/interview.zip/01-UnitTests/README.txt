This is quite simple.

Fix the code, so that the unit tests pass.
build.xml is provided
