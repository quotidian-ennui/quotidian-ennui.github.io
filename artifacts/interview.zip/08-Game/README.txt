Task:

Write an implementation of "Rock paper scissors lizard spock" (http://en.wikipedia.org/wiki/Rock-paper-scissors-lizard-Spock)

The UI can be whatever you wish, as simple or as complicated as you like.




