
Write a java program that iterates through all the numbers between 1 and 200000 and print out all the
ones that are a power of two



