
I am going to buy pairs of black socks that are printed with the Day of the week, and also the day of the month (e.g. Saturday 4). I shall be wearing each pair of socks on the appropriate day, i.e. on Tuesday 1st Jan 2013, I will be wearing the pair that has "Tuesday 1" printed on them, on 2nd Jan 2013; I will be wearing "Wednesday 2" and so on and so forth.

What is the least number of pairs that I will need to buy for the year 2013; the year will be the input to your program

For extra credit; I will be wanting to wear a different pair of socks, gold coloured with the day of week + day of month printed on them for each of the following "special occasion days"

- Chinese New Year
- Eid ul-Fitr
- Easter Sunday


What days will be printed on these socks.




