Take the given input file (input.properties) and write it out again to a new file (output.properties) discarding the prefix "prefix"

i.e. the contents of the output file would be

test.cfg.root=/test/cfg
certificate.country=GB
# additional Data skipped here.
ca.certificate.keyalgorithm.size=768

